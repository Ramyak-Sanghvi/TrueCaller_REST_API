INSTALLATION

1) Unzip the compressed folder containing the application into a suitable directory of your choice.

2) Go to the unzipped folder and activate virtual environment:

Example for Windows : (I have my repository in "D:")

=> Type following commands in Command Prompt :

i) d:

ii) cd codingTask

iii) .\Scripts\activate

3) Now go to apiTask folder which is in current directory to run our Django project.

=> Continue in Command Prompt where we left in step 2 :

iv) cd apiTask

v) python manage.py makemigrations

vi) python manage.py migrate

vii) python manage.py runserver

5) Take the HTTP address from the line beginning with "Starting development server at...".Put that web address into a web browser of your choice and go to it. The URL you enter should look something like this: http://127.0.0.1:8000

6) You now have the Django application running.

7) There will be no homepage at http://127.0.0.1:8000 , so you will get "Page not found" (404) Error!

=> Use https://jsonformatter.org/ to see proper json formatted output of our API

8) To access API , goto http://127.0.0.1:8000/api/ (It is general api displaying all our detail including users with it's contact and spams)

9) For searching use:

=> Search by name: http://127.0.0.1:8000/api/user/<name>

Example: http://127.0.0.1:8000/api/user/rajender

=> Search by Phone Number: http://127.0.0.1:8000/api/user/<phoneNumer>

Example:

-> Registered User: http://127.0.0.1:8000/api/user/9824650999

-> Unregistered User but in Contacts: http://127.0.0.1:8000/api/user/9824655999