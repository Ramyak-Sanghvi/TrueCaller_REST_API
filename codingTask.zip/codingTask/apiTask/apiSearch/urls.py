from django.urls import path
from .views import (
    UserInfo,
    SearchInfo,
)

app_name = 'apiSearch'
urlpatterns = [
    path('', UserInfo.as_view()),
    path('user/<detail>', SearchInfo.as_view()),
]