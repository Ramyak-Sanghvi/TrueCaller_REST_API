from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import User, Contact, Spam
from rest_framework.renderers import JSONRenderer
from .serializers import UserSerializer, ContactSerializer, SpamSerializer, SearchUserSerializer, SearchPhoneUserSerializer, SearchContactSerializer

# Create your views here.

def dummyDataInsertionCode():
    try:
        from openpyxl import load_workbook
        book = load_workbook('data.xlsx')
        sheet = book.active
        l=9999
        for i in range (5000):
            phoneNumber = sheet.cell(row=i+1, column=1)
            name = sheet.cell(row=i+1, column=3)
            email = sheet.cell(row=i+1, column=2)
            print(name.value,"s",i+1)
            user=User(phoneNumber=round(phoneNumber.value),name=name.value,email=email.value)
            user.save()
            for j in range (4):
                phoneNumber = sheet.cell(row=i+j+3100, column=1)
                name = sheet.cell(row=i+j+3100, column=3)
                contact=Contact(phoneNumber=round(phoneNumber.value),name=name.value)
                contact.save()
                user.contacts.add(contact)
            if i%2==0:
                for k in range (2):
                    phoneNumber = sheet.cell(row=l, column=1)
                    spam=Spam(phoneNumber=round(phoneNumber.value))
                    spam.save()
                    user.spamActions.add(spam)
                    l-=1
    except Exception as ex:
            print(ex) 


class UserInfo(APIView):
    renderer_classes = [JSONRenderer]
    def get(self, request):
        try:
            #dummyDataInsertionCode()
            users=User.objects.all()
            serializer=UserSerializer(users, many=True)
            return Response(serializer.data)
        except Exception as ex:
            print(ex)

class SearchInfo(APIView):
    renderer_classes=[JSONRenderer]
    def get(self,request,**kwargs):
        try:
            search=kwargs['detail']
            if search.isdigit():
                user=User.objects.filter(phoneNumber=search)
                serializer=SearchPhoneUserSerializer(user,many=True)
                if len(serializer.data)!=0:
                    for data in serializer.data:
                        spams=Spam.objects.filter(phoneNumber=data['phoneNumber'])
                        spamSerializer=SpamSerializer(spams,many=True)
                        data['spamCounts']=len(spamSerializer.data)
                    return Response(serializer.data)
                else:
                    contacts=Contact.objects.filter(phoneNumber=search)
                    serializer=SearchContactSerializer(contacts,many=True)
                    for data in serializer.data:
                        spams=Spam.objects.filter(phoneNumber=data['phoneNumber'])
                        spamSerializer=SpamSerializer(spams,many=True)
                        data['spamCounts']=len(spamSerializer.data)
                    return Response(serializer.data)
                
            else:
                users=User.objects.filter(name__startswith=search)
                serializer1=SearchUserSerializer(users,many=True)
                contacts=Contact.objects.filter(name__startswith=search)
                serializer2=SearchContactSerializer(contacts,many=True)
                users=User.objects.filter(name__contains=search).exclude(name__startswith=search)
                serializer3=SearchUserSerializer(users,many=True)
                contacts=Contact.objects.filter(name__contains=search).exclude(name__startswith=search)
                serializer4=SearchContactSerializer(contacts,many=True)
                serializer=serializer1.data+serializer2.data+serializer3.data+serializer4.data
                for data in serializer:
                    spams=Spam.objects.filter(phoneNumber=data['phoneNumber'])
                    spamSerializer=SpamSerializer(spams,many=True)
                    data['spamCounts']=len(spamSerializer.data)
                return Response(serializer)
        except Exception as ex:
            print(ex)