from rest_framework import serializers
from .models import User, Contact, Spam

class SpamSerializer(serializers.ModelSerializer):
    class Meta:
        model=Spam
        exclude=('id',)

class ContactSerializer(serializers.ModelSerializer):
    class Meta:
        model=Contact
        fields=('phoneNumber','name')

class UserSerializer(serializers.ModelSerializer):
    contacts=ContactSerializer(Contact.objects.all(),many=True)
    spamActions=SpamSerializer(Spam.objects.all(),many=True)
    class Meta:
        model=User
        fields=('phoneNumber','name','email','contacts','spamActions')


class SearchContactSerializer(serializers.ModelSerializer):
    class Meta:
        model=Contact
        fields=('name','phoneNumber')

class SearchUserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=('name','phoneNumber')

class SearchPhoneUserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=('phoneNumber','name','email')