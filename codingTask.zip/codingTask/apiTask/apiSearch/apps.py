from django.apps import AppConfig


class ApisearchConfig(AppConfig):
    name = 'apiSearch'
