from django.db import models

# Create your models here.

class Contact(models.Model):
    phoneNumber = models.CharField(max_length=10)
    name = models.CharField(max_length=25)

class Spam(models.Model):
    phoneNumber = models.CharField(max_length=10)

class User(models.Model):
    phoneNumber = models.CharField(primary_key=True,max_length=10)
    name = models.CharField(max_length=25)
    email = models.TextField(blank=True, null=True)
    contacts=models.ManyToManyField(Contact)
    spamActions=models.ManyToManyField(Spam)